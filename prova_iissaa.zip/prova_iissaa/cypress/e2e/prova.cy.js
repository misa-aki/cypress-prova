describe('Testes de Login - SauceDemo', () => {

  beforeEach(() => {
    cy.visit('/');
  });

  it('deve realizar login com sucesso usando usuário e senha válidos', () => {
    cy.login('standard_user', 'secret_sauce');
    cy.url().should('include', '/inventory.html');
  });

  it('deve exibir mensagem de erro ao usar senha inválida', () => {
    cy.login('standard_user', 'senha_errada');
    cy.get('[data-test="error"]').should('have.text', 'Epic sadface: Username and password do not match any user in this service');
  });

  it('deve exibir mensagem de erro ao usar usuário inválido', () => {
    cy.login('usuario_invalido', 'secret_sauce');
    cy.get('[data-test="error"]').should('have.text', 'Epic sadface: Username and password do not match any user in this service');
  });

  it('deve permitir adicionar um item ao carrinho após o login', () => {
    cy.login('standard_user', 'secret_sauce');
    cy.url().should('include', '/inventory.html');

    cy.contains('button', 'Add to cart').first().click();

    cy.get('.shopping_cart_badge').should('have.text', '1');
  });

});